# medium_korea_font

미디움 한글 포스팅의 본문 글꼴을 나눔고딕이나 맑은 고딕으로 바꿔주는 구글 크롬 확장도구

## Get Started

[확장도구 설치하기](https://chrome.google.com/webstore/detail/medium-korea-font/kokpfknnegehljlpmbddjhlmbcbbmpbh)
